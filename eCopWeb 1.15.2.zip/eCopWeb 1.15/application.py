from myapp import create_app
k=create_app()

if __name__ == '__main__':
    k.run(debug=True)