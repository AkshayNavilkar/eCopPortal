#!/usr/bin/env python
# -*- coding: utf-8 -*-

from flask import Flask
from flask_caching import Cache
import os

def create_app():
    application = myapp = Flask(__name__)
    myapp.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
    cache = Cache(myapp, config={'CACHE_TYPE': 'null'})
    cache.init_app(myapp)
    myapp.config["SECRET_KEY"] = "bepositive"
    from myapp.routes import main
    from myapp.users.routes import user
    from myapp.complaints.routes import posts
    from myapp.errors.handlers import errors
    from myapp.wanted.routes import wanted
    from myapp.front_page.routes import front_page
    from myapp.events.routes import events
    myapp.register_blueprint(main)
    myapp.register_blueprint(user)
    myapp.register_blueprint(posts)
    myapp.register_blueprint(errors)
    myapp.register_blueprint(wanted)
    myapp.register_blueprint(front_page)
    myapp.register_blueprint(events)
    return myapp
