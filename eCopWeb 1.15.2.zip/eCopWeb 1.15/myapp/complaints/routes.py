from flask import (render_template, url_for, flash,
                   redirect, request, abort, Blueprint)
from flask_login import current_user, login_required
from myapp.complaints.forms import statusform, complaintdocform
from myapp.users.fireconnect import bucket, db ,auth, downloadDocs
from myapp.session import readJson
from myapp.session import logged_in
posts = Blueprint('posts', __name__)

@posts.route("/post/status", methods=['GET', 'POST'])
def change_status():
    form = statusform()
    if logged_in():
        if form.validate_on_submit():
            cid = form.complaintid.data
            stat = form.changestatus.data
            status_details = form.additionaldetails.data
            doc_ref = db.collection('complaints').document(cid)
            doc = doc_ref.get()
            if doc.exists:
                ref = db.collection('complaints').document(cid)
                ref.update({
                    'status': stat,
                    'status_details': status_details
                })
                flash('Status changed!', 'success')
                return render_template('complaints/complaint_status.html', usr=1, form=form, legend='Change status')
            flash(f'No complaint exist', 'danger')
            return render_template('complaints/complaint_status.html', usr=1, form=form, legend='Change status')
        return render_template('complaints/complaint_status.html', usr=1, form=form, legend='Change status')
    flash(f"You are not signed in. Please sign in to continue.", "danger")
    return redirect(url_for('user.login'))

@posts.route("/post/view", methods=['GET','POST'])
def view_complaints():
    if logged_in():
        docs = db.collection(u'complaints').stream()
        doclist = []
        for doc in docs:
            doc = doc.to_dict()
            doclist.append(doc)
        return render_template('complaints/viewcomplaints.html', usr=1, legend='View Complaints',doclist=doclist)
    flash(f"You are not signed in.Please sign in to continue.", "danger")
    return redirect(url_for('user.login'))

@posts.route("/post/downloadcomplaintdocs", methods=['GET','POST'])
def download_complaint_docs():
    form = complaintdocform()
    if logged_in():
        if form.validate_on_submit():
            cid = form.complaintid.data
            doc_ref = db.collection('complaints').document(cid)
            doc = doc_ref.get()
            if doc.exists:
                k = 'default.zip'
                ref = db.collection('complaints').document(cid)
                doc = ref.get().to_dict()
                if doc['docs']:
                    downloadDocs(cid)
                    flash(f"The requested file has been downloaded. Please check the 'static/complaint_docs' folder with complaintid as filename", "success")
                    return render_template('complaints/downloadcomplaintdocs.html', usr=1, form=form, legend='Download documents')
                flash(f'No documents exist', 'danger')
                return render_template('complaints/downloadcomplaintdocs.html', usr=1, form=form, legend='Download documents')
            flash(f"Complaint not found, retry with a valid complaint-id", "danger")
            return render_template('complaints/downloadcomplaintdocs.html', usr=1, form=form, legend='Download documents')
        return render_template('complaints/downloadcomplaintdocs.html', usr=1, form=form, legend='Download documents')
    flash(f"You are not signed in.Please sign in to continue.", "danger")
    return redirect(url_for('user.login'))
