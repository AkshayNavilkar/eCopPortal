config = {
    "apiKey": "AIzaSyCtImqLEFEO0wEs1F8VKlHTdhaAXqlCx_w",
    "authDomain": "ecop-6ea85.firebaseapp.com",
    "databaseURL": "https://ecop-6ea85.firebaseio.com",
    "projectId": "ecop-6ea85",
    "storageBucket": "ecop-6ea85.appspot.com",
    "messagingSenderId": "752986824452",
    "appId": "1:752986824452:web:8448d2fe6ab6e8caa33a51",
    "measurementId": "G-P2DKPMLHZM"
}