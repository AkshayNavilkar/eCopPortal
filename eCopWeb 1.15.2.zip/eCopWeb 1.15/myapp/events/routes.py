from flask import (render_template, url_for, flash,
                   redirect, request, abort, Blueprint)
from myapp.events.forms import statusform
from myapp.users.fireconnect import bucket, db ,auth, downloadDocs
from myapp.session import readJson
from myapp.session import logged_in

events = Blueprint('events', __name__)
@events.route("/events/view", methods=['GET','POST'])
def view_events_requests():
    if logged_in():
        docs = db.collection(u'events').stream()
        doclist = []
        for doc in docs:
            doc = doc.to_dict()
            doclist.append(doc)
        return render_template('events/viewevents.html', usr=1, legend='View Event Requests',doclist=doclist)
    flash(f"You are not signed in.Please sign in to continue.", "danger")
    return redirect(url_for('user.login'))

@events.route("/events/status", methods=['GET','POST'])
def change_status():
    form = statusform()
    if logged_in():
        if form.validate_on_submit():
            doc_ref = db.collection('events').document(form.eventid.data)
            doc = doc_ref.get()
            if doc.exists:
                ref = db.collection('events').document(form.eventid.data)
                ref.update({
                    'event_status': form.changestatus.data,
                    'status_details': form.additionaldetails.data
                })
                flash('Status changed!', 'success')
                return render_template('events/eventstatus.html', usr=1, form=form, legend='Change Event Status')
            flash(f'No entry', 'danger')
            return render_template('events/eventstatus.html', usr=1, form=form, legend='Change Event status')
        return render_template('events/eventstatus.html', usr=1, form=form, legend='Change Event status')
    flash(f"You are not signed in. Please sign in to continue.", "danger")
    return redirect(url_for('user.login'))