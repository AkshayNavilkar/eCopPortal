from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, SelectField, TextAreaField, DateField, TimeField,FileField
from wtforms.validators import DataRequired
from flask_wtf.file import FileField, FileAllowed
# from myapp.complaints.datasetreader import generatecity

# '''class PostForm(FlaskForm):
#     title = StringField('Title', validators=[DataRequired()])
#     typeofcrime = SelectField('Type of Crime', validators=[DataRequired()], choices = [('Select type','Select type'),('Dowry Harrasment','Dowry Harrasment'),('Family discord','Family discord'),('Kidnapping','Kidnapping'),('Rape','Rape'),('Workplace harassment','Workplace harassment'),('Female feticide','Female feticide'),('Eve-teasing','Eve-teasing'),('Abondonment of the girl child','Abondonment of the girl child'),('Any other','Any other')])
#     description = TextAreaField('Description')
#     city = SelectField('City', validators=[DataRequired()], choices = generatecity())
#     date = DateField('Date', format='%d-%m-%Y', validators=[DataRequired()])
#     time = TimeField('Time', format='%H-%M-%S', validators=[DataRequired()])
#     docs = FileField('Documents')
#     submit = SubmitField('Post')'''

# #Please return a complaint id after registering (Example: CMP000000001 ('CMP' followed by 12-digit id)) every complaint which will be helpful in checking/changing status of the complaint

class AddFPContentForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired()])
    description = StringField('Descrption', validators=[DataRequired()])
    picture = FileField('Content Picture', validators=[FileAllowed(['jpg', 'png', 'jpeg']), DataRequired()])
    submit = SubmitField('Submit')

class RemoveFPContentForm(FlaskForm):
	title = StringField('Title', validators=[DataRequired()])
	submit = SubmitField('Remove')
