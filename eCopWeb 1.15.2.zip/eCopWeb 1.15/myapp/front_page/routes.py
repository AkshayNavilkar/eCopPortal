from flask import (render_template, url_for, flash,
                   redirect, request, abort, Blueprint)
from flask_login import current_user, login_required
from myapp.front_page.forms import AddFPContentForm, RemoveFPContentForm
from myapp.users.fireconnect import bucket, db ,auth, downloadcontentPic
from myapp.session import readJson, save_content_picture
from myapp.session import logged_in
from flask import flash,current_app
import os
front_page = Blueprint('front_page', __name__)

@front_page.route('/front/logo')
def logo():
    if logged_in():
        return render_template("front_page/logo.html", usr=1)
    return render_template("front_page/logo.html", usr=0)

@front_page.route("/front/add", methods=['GET', 'POST'])
def add_fp_content():
    form = AddFPContentForm()
    if logged_in():
        if form.validate_on_submit():
            doclist=[]
            docs = db.collection(u'front_page').stream()
            for doc in docs:
                doclist.append(doc.id)
            if not len(doclist) >= 3:
                if form.picture.data:
                    data = {    u'title': form.title.data,
                                u'description': form.description.data,
                                u'picture': False    }
                    ID = []
                    db.collection(u'front_page').add(data)
                    docs = db.collection(u'front_page').where(u'title', u'==', form.title.data).where(u'description', u'==', form.description.data).stream()
                    for doc in docs:
                        ID.append(doc.id)
                    db.collection(u'front_page').document(ID[0]).update({u'content_id': ID[0]})
                    save_content_picture(form.picture.data, ID[0])
                    downloadcontentPic(ID[0])
                    flash(f"Content added!", "success")
                    return render_template('front_page/add_front_content.html', usr=1, form=form, legend='Add Content')
                flash(f"Please select an image.", "danger")
                return render_template('front_page/add_front_content.html', usr=1, form=form, legend='Add Content')
            flash(f"Only three can be added. Please delete to add new", "danger")
            return render_template('front_page/add_front_content.html', usr=1, form=form, legend='Add Content')
        return render_template('front_page/add_front_content.html', usr=1, form=form, legend='Add Content')
    flash(f"You are not signed in. Please sign in to continue.", "danger")
    return redirect(url_for('user.login'))

@front_page.route("/front/delete", methods=['GET', 'POST'])
def remove_fp_content():
    form = RemoveFPContentForm()
    if logged_in():
        if form.validate_on_submit():
            ID = []
            docs = db.collection(u'front_page').where(u'title', u'==', form.title.data).stream()
            for doc in docs:
                ID.append(doc.id)
                print(ID)
            if ID:
                doc = db.collection(u'front_page').document(ID[0]).get()
                db.collection(u'front_page').document(ID[0]).delete()
                os.remove(''+current_app.root_path+'/static/content_pics/'+ID[0]+'.png') 
                flash(f'Deleted!','success')
                return render_template('front_page/remove_front_content.html', usr=1, form=form, legend='Remove Content')
            flash(f'Record not found!','danger')
            return render_template('front_page/remove_front_content.html', usr=1, form=form, legend='Remove Content')
        return render_template('front_page/remove_front_content.html', usr=1, form=form, legend='Remove Content')
    flash(f"You are not signed in.Please sign in to continue.", "danger")
    return redirect(url_for('user.login'))