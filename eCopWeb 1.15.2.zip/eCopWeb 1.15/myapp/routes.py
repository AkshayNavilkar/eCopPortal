from flask import render_template, Blueprint
from myapp.session import logged_in
from myapp.users.fireconnect import downloadcontentPic
from flask import (render_template, url_for, flash,
                   redirect, request, abort, Blueprint)
from myapp.users.fireconnect import bucket, db
import pandas as pd

main=Blueprint('main',__name__)

@main.route('/')
@main.route('/index')
def index():
	doclist = []
	piclist = []
	docs = db.collection(u'front_page').stream()
	for doc in docs:
		doclist.append(doc.to_dict())
		piclist.append(url_for('static', filename='content_pics/'+doc.id+'.png'))
	doclen = len(doclist)
	if logged_in():
		return render_template("index.html", usr=1, doclist = pd.DataFrame(doclist), doclen = doclen, piclist = piclist)
	return render_template("index.html", usr=0, doclist = pd.DataFrame(doclist), doclen = doclen, piclist = piclist)
	
@main.route('/about')
def about():
	if logged_in():
		return render_template("about.html", usr=1)
	return render_template("about.html", usr=0)

@main.route('/menu')
def menu():
	if logged_in():
		return render_template("menu.html", usr=1)
	flash(f"You are not signed in. Please sign in to continue.", "danger")
	return redirect(url_for('user.login'))