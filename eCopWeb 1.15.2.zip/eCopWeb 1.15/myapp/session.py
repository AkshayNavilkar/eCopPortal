from myapp import session
from myapp.users.forms import UpdateAccountForm
from myapp.users.fireconnect import firelogin,CreateUser,downloadPic,uploadPic,uploadwantedPic,updateUser,uploadcontentPic
import json
import os
from PIL import Image
from flask import current_app

auth=0

def readJson():
    with open('myapp/credentials/udata.json') as infile:
        data=json.load(infile)
        for p in data['user']:
            profile={
                "Name":p['Name'],
                "Email":p['Email'],
                "Password":p['Password'],
                "Usertype":p['Usertype'],
                "Remember":p['Remember'],
                "ID":p['ID']
                }
    infile.close()
    return profile

def writeJson(rec):
    old=readJson()
    name=old['Name']
    mail=old['Email']
    pwd=old['Password']
    utype=old['Usertype']
    rem=old['Remember']
    uid=old['ID']
    if rec['Name']:
        name=rec['Name']
    if rec['Email']:
        mail=rec['Email']
    if rec['Password']:
        pwd=rec['Password']
    if rec['Usertype']:
        utype=rec['Usertype']
    if rec['Remember']:
        rem=rec['Remember']
    if rec['ID']:
        uid=rec['ID']
    data={}
    data['user']=[]
    data['user'].append
    ({
        "Name":name,
        "Email":mail,
        "Password":pwd,
        "Usertype":utype,
        "Remember":rem,
        "ID":uid
        })
    with open('myapp/credentials/udata.json','w') as outfile:
        json.dump(data,outfile)
    outfile.close()

def logged_in():
    if session.auth==0:
        session.auth=check()
    if session.auth==1:
        return True
    else:
        return False

def signup(uname,mail,utype,pwd):
    if CreateUser(uname,mail,utype,pwd):
        return True
    return False

def check():
    data=readJson()
    if data['Remember']==True:
        if firelogin(data['Email'],data['Password']):
            session.auth=1
        else:
            session.auth=2
    else:
            session.auth=2
    return session.auth

def log_in(mail,pwd,rem):
    usr=firelogin(mail,pwd)
    if usr:
        session.auth=1
        data={}
        data['user']=[]
        data['user'].append({
            "Name":usr['Name'],
            "Email":usr['Email'],
            "Password":usr['Password'],
            "Usertype":usr['Usertype'],
            "Remember":rem,
            "ID":usr['ID']
        })
        with open('myapp/credentials/udata.json','w') as outfile:
            json.dump(data,outfile)
        outfile.close()
        return True
    else:
        session.auth=2
        return False
    
def loadProfile(form):
    k=readJson()
    form=UpdateAccountForm()
    form.username.data=k['Name']
    form.email.data=k['Email']
    form.usertype.data=k['Usertype']
    return form

def getPic():
    k=readJson()
    pic=downloadPic(k['ID'])
    return pic

def updateUsr(un,em):
    k=readJson()
    l=False
    if un != k['Name']:
        l=updateUser(k['ID'],un,False)
    if em != k['Email']:
        l=updateUser(k['ID'],False,em)
    if l:
        print(un,k['Name'],em,k['Email'])
        data={}
        data['user']=[]
        data['user'].append({
            "Name":un,
            "Email":em,
            "Password":k['Password'],
            "Usertype":k['Usertype'],
            "Remember":k['Remember'],
            "ID":k['ID']
        })
        with open('myapp/credentials/udata.json','w') as outfile:
            json.dump(data,outfile)
        outfile.close()
    return True
    
def log_out():
    data={}
    data['user']=[]
    data['user'].append({
        "Name":"Name",
        "Email":"Email",
        "Password":"Password",
        "Usertype":'Usertype',
        "Remember":False,
        "ID":'ID'
    })
    with open('myapp/credentials/udata.json','w') as outfile:
        json.dump(data,outfile)
    outfile.close()
    session.auth=2
    return True

def save_picture(form_picture):
    k=readJson()
    picture_fn = ''+k['ID']+'.png'
    picture_path = os.path.join(current_app.root_path, 'static/profile_pics',picture_fn)
    output_size = (125, 125)
    i = Image.open(form_picture)
    i.thumbnail(output_size)
    i.save(picture_path)
    if uploadPic(k['ID']):
        return picture_fn
    return False

def save_wanted_picture(form_picture, wid):
    picture_fn = ''+wid+'.png'
    picture_path = os.path.join(current_app.root_path, 'static/wanted_pics',picture_fn)
    i = Image.open(form_picture)
    j = i.resize((200, 200))
    j.save(picture_path)
    if uploadwantedPic(wid):
        return picture_fn
    return False

def save_content_picture(form_picture, wid):
    picture_fn = ''+wid+'.png'
    picture_path = os.path.join(current_app.root_path, 'static/content_pics',picture_fn)
    i = Image.open(form_picture)
    j = i.resize((640, 320))
    j.save(picture_path)
    if uploadcontentPic(wid):
        return picture_fn
    return False

