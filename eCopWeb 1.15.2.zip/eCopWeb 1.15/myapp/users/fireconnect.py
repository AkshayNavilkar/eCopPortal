from firebase_admin import credentials,auth,firestore,storage
import firebase_admin
from myapp.credentials.pyreconfig import config
from flask import flash,current_app
from requests import HTTPError, Timeout, ConnectTimeout, ReadTimeout, ConnectionError
import pyrebase
import json
import os
import yagmail
import string 
import random 

cred = credentials.Certificate("myapp/credentials/key.json")
firebase_admin.initialize_app(cred,{'storageBucket': 'ecop-6ea85.appspot.com'})
db = firestore.client()
bucket = storage.bucket()
firebase = pyrebase.initialize_app(config)
pyreauth = firebase.auth()


def firelogin(mail,pwd):
    try:
        usr = auth.get_user_by_email(mail)
        ref = db.collection('users').document(usr.uid)
        doc = ref.get().to_dict()
        if doc['Usertype'] == 'Administrator':
            user=pyreauth.sign_in_with_email_and_password(mail,pwd)
            if user:
                flash('Hello '+doc['Name']+ ', Welcome to eCop portal.', 'success')
                return doc
        else:
            flash(f'<<ACCESS DENIED!>> Invalid user type. Only Administrators can use this application','danger')
            return False
    except HTTPError as e:
        response = e.args[0].response
        error = response.json()['error']
        flash(error['message'], 'danger')
        return False
    except (Timeout,ConnectTimeout,ReadTimeout,ConnectionError):
        flash('Check Your Internet connection', 'danger')
        return False
    except Exception as e:
        flash(e, 'danger')
        return False

def resetPassword(mail):
    try:
        N = 6
        res = ''.join(random.choices(string.ascii_uppercase +string.digits, k = N))
        res = str(res)
        docs = db.collection(u'users').where(u'Email', u'==', mail).stream()
        MAIL_USER = os.environ.get('EMAIL_USER')
        MAIL_PASS = os.environ.get('EMAIL_PASS')
        print('{} {}'.format(MAIL_USER, MAIL_PASS))
        for doc in docs:
            ID = doc.id
            db.collection(u'users').document(ID).update({u'Password': res})
            user = auth.update_user(ID,password=res)
        yag = yagmail.SMTP(MAIL_USER, MAIL_PASS)
        contents = "Your recent password request has been received successfully. Your new password is "+res+". Please change the password after logging in."
        yag.send(mail, 'Password Reset', contents)
        return True
    except Exception as e:
        flash(e, 'danger')
        return False

def CreateUser(un,em,ut,pw):
    try:
        user = auth.create_user(
            display_name=un,
            email=em,
            password=pw
        )
        data = {
            u'Name': un,
            u'Email': em,
            u'Usertype': ut,
            u'Password': pw,
            u'ID': user.uid,
            u'Photo': False            
        }
        doc_ref = db.collection(u'users').document(user.uid)
        doc_ref.set(data)
        flash(f"Account created for {un}. Login to access your account", "success")
        return True
    except HTTPError as e:
        response = e.args[0].response
        error = response.json()['error']
        flash(error['message'], 'danger')
        return False
    except (Timeout,ConnectTimeout,ReadTimeout,ConnectionError):
        flash('Check Your Internet connection', 'danger')
        return False
    except firebase_admin.exceptions.FirebaseError as ez:
        flash(ez, 'danger')
        return False

def updateUser(uid,uname,email):
    try:
        if uname:
            auth.update_user(uid, display_name=uname)
            data = {u'Name': uname}
            doc_ref = db.collection(u'users').document(uid)
            doc_ref.set(data, merge=True)
        if email:
            auth.update_user(uid, email=email)
            data = {u'Email': email}
            doc_ref = db.collection(u'users').document(uid)
            doc_ref.set(data, merge=True)
        flash('Your account has been updated!', 'success')
        return True
    except Exception as e:
        flash(e, 'danger')
        return False

def uploadPic(uid):
    try:
        blob = bucket.blob('profilePics/'+uid+'.png')
        blob.upload_from_filename(os.path.join(current_app.root_path, 'static/profile_pics/'+uid+'.png'))
        data = {
                u'Photo': True
            }
        doc_ref = db.collection(u'users').document(uid)
        doc_ref.set(data, merge=True)
        flash('Profile picture has been updated!', 'success')
        return True
    except Exception as e:
        print(e)
        return False

def uploadwantedPic(uid):
    try:
        blob = bucket.blob('wantedPics/'+uid+'.png')
        blob.upload_from_filename(os.path.join(current_app.root_path, 'static/wanted_pics/'+uid+'.png'))
        data = {
                u'picture': True
            }
        doc_ref = db.collection(u'wanted_list').document(uid)
        doc_ref.set(data, merge=True)
        flash('Picture has been updated!', 'success')
        return True
    except Exception as e:
        print(e)
        return False

def uploadcontentPic(uid):
    try:
        blob = bucket.blob('contentPics/'+uid+'.png')
        blob.upload_from_filename(os.path.join(current_app.root_path, 'static/content_pics/'+uid+'.png'))
        data = {
                u'picture': True
            }
        doc_ref = db.collection(u'front_page').document(uid)
        doc_ref.set(data, merge=True)
        flash('Picture has been updated!', 'success')
        return True
    except Exception as e:
        print(e)
        return False

def downloadPic(uid):
    k='default.png'
    ref = db.collection('users').document(uid)
    doc = ref.get().to_dict()
    if doc['Photo']:
        try:
            blob = bucket.blob('profilePics/'+uid+'.png')
            blob.download_to_filename(os.path.join(current_app.root_path, 'static/profile_pics/'+uid+'.png'))
            k=''+uid+'.png'
            return k
        except Exception as e:
            flash(e, 'danger')
    return k

def downloadwantedPic(uid):
    k='default.png'
    ref = db.collection('wanted_list').document(uid)
    doc = ref.get().to_dict()
    if doc['picture']:
        try:
            blob = bucket.blob('wantedPics/'+uid+'.png')
            blob.download_to_filename(os.path.join(current_app.root_path, 'static/wanted_pics/'+uid+'.png'))
            k=''+uid+'.png'
            return k
        except Exception as e:
            flash(e, 'danger')
    return k

def downloadcontentPic(uid):
    k='default.png'
    ref = db.collection('front_page').document(uid)
    doc = ref.get().to_dict()
    if doc['picture']:
        try:
            blob = bucket.blob('contentPics/'+uid+'.png')
            blob.download_to_filename(os.path.join(current_app.root_path, 'static/content_pics/'+uid+'.png'))
            k=''+uid+'.png'
            return k
        except Exception as e:
            flash(e, 'danger')
    return k

def downloadDocs(cid):
    try:
        blob = bucket.blob('complaintDocs/'+cid+'.zip')
        blob.download_to_filename(os.path.join(
            current_app.root_path, 'static/complaint_docs/'+cid+'.zip'))
    except Exception as e:
        flash(e, 'danger')

