from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, PasswordField, SelectField, SubmitField, BooleanField
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError

class RegistrationForm(FlaskForm):
    username = StringField('User Name',
                           validators=[DataRequired(), Length(min=2, max=20)])
    def validate_username(self, username):
        if not username.data.isalpha():
            raise ValidationError('User name must not contain digits/symbols.')
    email = StringField('Email',
                        validators=[DataRequired(), Email()])
    usertype = SelectField('User Type',
        validators=[DataRequired()], choices=[('Select any', 'Select any'), ('Administrator', 'Administrator'), ('Civilian', 'Civilian')])
    def validate_usertype(self, usertype):
        if usertype.data == "Select any":
            raise ValidationError('Not a valid selection, Please select a valid option.')
    
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6, max=15)])
    confirm_password = PasswordField('Confirm Password',
                                     validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Sign Up')

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')

class UpdateAccountForm(FlaskForm):
    username = StringField('User Name', validators=[DataRequired(), Length(min=2, max=20)])
    def validate_username(self, username):
        if username.data[0].isdigit():
            raise ValidationError('User name must not start with a digit')
    email = StringField('Email', validators=[DataRequired(), Email()])
    picture = FileField('Update Profile Picture', validators=[FileAllowed(['jpg', 'png', 'jpeg'])])
    usertype = StringField('User Type',validators=[DataRequired()])
    submit = SubmitField('Update')

class ChangePasswordForm(FlaskForm):
    admin_password = PasswordField('Administrator password', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6, max=15)])
    confirm_password = PasswordField('Confirm Password',
                                         validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Update')

class ResetPasswordForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    submit = SubmitField('Reset')