from flask import render_template,url_for,flash,redirect, Blueprint,request
from myapp.users.forms import RegistrationForm,LoginForm,UpdateAccountForm, ChangePasswordForm, ResetPasswordForm
from myapp.session import logged_in, log_out,log_in,save_picture,signup,loadProfile,getPic,updateUsr,readJson
from myapp.users.fireconnect import CreateUser,uploadPic, resetPassword
from myapp.users.fireconnect import bucket, db ,auth
from firebase_admin import credentials,auth,firestore,storage


user=Blueprint('user',__name__)

@user.route('/register', methods=['GET','POST'])
def register():
    form=RegistrationForm()
    if logged_in():
        if form.validate_on_submit():
            if signup(form.username.data, form.email.data,form.usertype.data,form.password.data):
                flash(f"Registration Succesful!", "success")
                return render_template("user/signup.html", form=form, usr=1)
    return render_template("user/signup.html", form=form, usr=1)

@user.route('/login', methods=['GET','POST'])
def login():
    if logged_in():
        return redirect(url_for('main.index'))
    form=LoginForm()
    if form.validate_on_submit():
        if log_in(form.email.data,form.password.data,form.remember.data):
            return redirect(url_for('main.index'))
    return render_template("user/login.html", form=form,usr=0)

@user.route('/account', methods=['GET','POST'])
def account():
    form=UpdateAccountForm()
    k=readJson()
    p=getPic()
    if logged_in():
        if form.validate_on_submit():
            updateUsr(form.username.data,form.email.data)
            k['Name'] = form.username.data
            k['Email'] = form.email.data
            if form.picture.data:
                p=save_picture(form.picture.data)
                return redirect(url_for('user.account'))
        elif request.method == 'GET':
            form.username.data=k['Name']
            form.email.data=k['Email']
            form.usertype.data=k['Usertype']
        image = url_for('static', filename='profile_pics/'+p)
        return render_template('user/account.html',usr=1,k=k, form=form, img=image, legend='Account Information')
    flash(f"Please login to access your account", "danger")
    return redirect(url_for('user.login'))

@user.route('/logout', methods=['GET','POST'])
def logout():
    if logged_in():
        if log_out():
            flash(f"Logout Succesful.", "success")
            return redirect(url_for('user.login'))
    flash(f"You are not signed in.", "danger")
    return redirect(url_for('user.login'))

@user.route('/changepassword', methods=['GET', 'POST'])
def change_password():
    form = ChangePasswordForm()
    k=readJson()
    if form.validate_on_submit():
        if logged_in():
            passwd = form.password.data
            conf_passwd = form.confirm_password.data
            admin_passwd = form.admin_password.data
            email = form.email.data
            doc_ref = db.collection('users').document(k['ID'])
            doc = doc_ref.get().to_dict()  
            doc1=[]
            docs = db.collection(u'users').where(u'Email', u'==', email).stream()
            for dot in docs:
                doc_usr = dot.to_dict()
            if admin_passwd == doc['Password']:
                if passwd != doc_usr['Password']:
                    if doc_usr['Usertype'] != 'Administrator' or doc_usr['Usertype'] == 'Administrator' and k['Email'] == doc_usr['Email']:
                        if passwd == conf_passwd:
                            ref = db.collection('users').document(doc_usr['ID'])
                            ref.update({
                                'Password': passwd
                            })
                            user = auth.update_user(doc_usr['ID'],password=passwd)
                            flash(f'Password changed successfully.','success')
                            return render_template('user/changepassword.html',usr=1, form=form)
                        else:
                            flash(f'Passwords do not match.','danger')
                            return render_template('user/changepassword.html',usr=1, form=form)
                    flash(f'<<ACCESS DENIED!>> Cannot change password for other administrator accounts.','danger')
                    return render_template('user/changepassword.html',usr=1, form=form)
                else:
                    flash(f'Please enter a new password.','danger')
                    return render_template('user/changepassword.html',usr=1, form=form)
            else:
                flash(f'Invalid administrator password! or Usertype is not Administrator','danger')
                return render_template('user/changepassword.html',usr=1, form=form)
        flash(f"You are not signed in.", "danger")
        return redirect(url_for('user.login'))
    return render_template('user/changepassword.html',usr=1, form=form)

@user.route('/resetpassword', methods=['GET', 'POST'])
def reset_password():
    form = ResetPasswordForm()
    if form.validate_on_submit():
        if log_out():
            docs = db.collection(u'users').where(u'Email', u'==', form.email.data).stream()
            for doc in docs:
                doc_usr = doc.to_dict()
                if not doc_usr == None:
                    resetPassword(form.email.data)
                    flash(f'Your new password has been sent to you in your email please check your inbox/spam box.','success')
                    return render_template('user/resetpassword.html',usr=0, legend='Reset Password', form=form)
            flash(f'No account with '+form.email.data+' was found.','danger')
            return render_template('user/resetpassword.html',usr=0, legend='Reset Password', form=form)
    return render_template('user/resetpassword.html',usr=0, legend='Reset Password', form=form)
