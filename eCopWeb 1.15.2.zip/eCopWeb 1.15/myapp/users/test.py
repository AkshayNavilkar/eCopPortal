import json

'''from firebase_admin import credentials,storage
import firebase_admin

try:
    cred = credentials.Certificate("C:/Users/Kumar/Desktop/Final_Project/eCopWeb/myapp/users/key.json")
    firebase_admin.initialize_app(cred,{'storageBucket': 'ecop-6ea85.appspot.com'})
    bucket = storage.bucket()
    blob = bucket.blob('py.txt')
    #blob.upload_from_string('hello world')
    blob.upload_from_filename('C:/Users/Kumar/Desktop/Final_Project/eCopWeb/k.py')
    # blob.download_to_filename('C:/Users/Kumar/Desktop/Final_Project/eCopWeb/hi.py')
    print('Success')
except Exception as e:
    print(e)
'''
'''user = auth.create_user(
        email='user@example.com',
        email_verified=False,
        phone_number='+15555550100',
        password='secretPassword',
        display_name='John Doe',
        photo_url='http://www.example.com/12345678/photo.png',
        disabled=False)'''

data={}
data['user']=[]
data['user'].append({
    "Name":"Name",
    "Email":"Email",
    "Password":"Password",
    "Usertype":'Usertype',
    "Remember":False,
    "ID":'ID'
})
with open('myapp/credentials/udata.json','w') as outfile:
    json.dump(data,outfile)
outfile.close()