from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, SelectField, TextAreaField, DateField, TimeField,FileField, IntegerField
from wtforms.validators import DataRequired, Length, NumberRange, ValidationError
from flask_wtf.file import FileField, FileAllowed

class AddToWantedForm(FlaskForm):
    fname = StringField('First Name', validators=[DataRequired(), Length(min=2, max=20)])
    def validate_fname(self, fname):
        if fname.data.isalnum() and not fname.data.isalpha():
            raise ValidationError('Only alphabets allowed.')

    lname = StringField('Last Name', validators=[DataRequired(), Length(min=2, max=20)])
    def validate_lname(self, lname):
        if lname.data.isalnum() and not lname.data.isalpha():
            raise ValidationError('Only alphabets allowed.')

    age = StringField('Age in years', validators=[DataRequired()])
    def validate_age(self, age):
        if not age.data.isdigit():
            raise ValidationError('Invalid data entered. Only numeric values allowed.')
        if (int(age.data) > 100) or (int(age.data) < 1):
            raise ValidationError('Age must be between 1 and 100.')
        

    height = StringField('Height in feets', validators=[DataRequired()])
    def validate_height(self, height):
        if not height.data.isdigit():
            raise ValidationError('Invalid data entered. Only numeric values allowed.')
        if (int(height.data) > 6) or (int(height.data) < 1):
            raise ValidationError('height must be between 1 and 6.')

    skintone = SelectField('Skin Tone', choices=[('Select any','Select any'), ('Very Fair', 'Very Fair'), ('Fair', 'Fair'), ('Olive', 'Olive'),('Light Brown','Light Brown'), ('Brown', 'Brown'), ('Dark Brown', 'Dark Brown'), ('Black Brown', 'Black Brown')])
    def validate_skintone(self, skintone):
        if skintone.data == "Select any":
            raise ValidationError('Not a valid selection, Please select a valid option.')

    bodytype = SelectField('Body Type', choices=[('Select any','Select any'), ('Ectomorph', 'Ectomorph'), ('Endomorph', 'Endomorph'), ('Mesomorph', 'Mesomorph')])
    def validate_bodytype(self, bodytype):
        if bodytype.data == "Select any":
            raise ValidationError('Not a valid selection, Please select a valid option.')

    picture = FileField('Picture', validators=[DataRequired()])

    bounty = StringField('Bounty', validators=[DataRequired()])
    def validate_bounty(self, bounty):
        if not bounty.data.isdigit():
            raise ValidationError('Invalid data entered. Only numeric values allowed.')

    wantedtype = SelectField('Type', choices=[('Select any','Select any'), ('Missing civilian', 'Missing civilian'), ('Wanted Criminal', 'Wanted Criminal')])
    def validate_wantedtype(self, wantedtype):
        if wantedtype.data == "Select any":
            raise ValidationError('Not a valid selection, Please select a valid option.')

    submit = SubmitField('Submit')

class RemoveFromWantedForm(FlaskForm):
    wantedid = StringField('Wanted ID', validators=[DataRequired()])
    submit = SubmitField('Remove')