from flask import (render_template, url_for, flash,
				   redirect, request, abort, Blueprint)
from flask_login import current_user, login_required
from myapp.wanted.forms import AddToWantedForm, RemoveFromWantedForm
from myapp.users.fireconnect import bucket, db ,auth, downloadDocs, downloadwantedPic
from myapp.session import readJson, save_wanted_picture
from myapp.session import logged_in
wanted = Blueprint('wanted', __name__)

@wanted.route("/wanted/add", methods=['GET', 'POST'])
def add_to_wanted_list():
	form = AddToWantedForm()
	if logged_in():
		skintone = url_for('static', filename='media/skintone.png')
		bodytype = url_for('static', filename='media/bodytype.png')
		if form.validate_on_submit():
			if form.picture.data:
				data = {	u'first_name': form.fname.data,
							u'last_name': form.lname.data,
							u'age': form.age.data,
							u'height': form.height.data,
							u'skin_tone': form.skintone.data,
							u'body_type': form.bodytype.data,
							u'picture': False,
							u'bounty': form.bounty.data,
							u'wanted_type': form.wantedtype.data	}
				ID = []
				db.collection(u'wanted_list').add(data)
				docs = db.collection(u'wanted_list').where(u'first_name', u'==', form.fname.data).where(u'last_name', u'==', form.lname.data).stream()
				for doc in docs:
					ID.append(doc.id)
				db.collection(u'wanted_list').document(ID[0]).update({u'wanted_id': ID[0]})
				save_wanted_picture(form.picture.data, ID[0])
				flash(f'Added to wanted list.','success')
				return render_template('wanted/addtowantedlist.html', usr=1, form=form, skintone = skintone, bodytype = bodytype, legend='Add to Wanted List')
			flash(f'Please select the picture of a wanted person','danger')
			return render_template('wanted/addtowantedlist.html', usr=1, form=form, skintone = skintone, bodytype = bodytype, legend='Add to Wanted List')
		return render_template('wanted/addtowantedlist.html', usr=1, form=form, skintone = skintone, bodytype = bodytype, legend='Add to Wanted List')
	flash(f"You are not signed in.Please sign in to continue.", "danger")
	return redirect(url_for('user.login'))

@wanted.route("/wanted/view", methods=['GET','POST'])
def view_wanted_list():
	if logged_in():
		docs = db.collection(u'wanted_list').stream()
		doclist = []
		piclist = []
		for doc in docs:
			doclist.append(doc.to_dict())
			piclist.append(url_for('static', filename='wanted_pics/'+downloadwantedPic(doc.id)))
		return render_template('wanted/viewwantedlist.html', usr=1, legend='_Wanted List', doclist = doclist, piclist = piclist)
	flash(f"You are not signed in.Please sign in to continue.", "danger")
	return redirect(url_for('user.login'))

@wanted.route("/wanted/remove", methods=['GET', 'POST'])
def remove_from_wanted_list():
	form = RemoveFromWantedForm()
	if logged_in():
		if form.validate_on_submit():
			print(form.wantedid.data)
			doc = db.collection('wanted_list').document(form.wantedid.data).get()
			print(doc)
			if doc.exists:
				db.collection(u'wanted_list').document(form.wantedid.data).delete()
				flash(f'Deleted from wanted list','success')
				return render_template('wanted/removefromwantedlist.html', usr=1, form=form, legend='Remove from Wanted List')
			flash(f'Record not found!','danger')
			return render_template('wanted/removefromwantedlist.html', usr=1, form=form, legend='Remove from Wanted List')
		return render_template('wanted/removefromwantedlist.html', usr=1, form=form, legend='Remove from Wanted List')
	flash(f"You are not signed in.Please sign in to continue.", "danger")
	return redirect(url_for('user.login'))
